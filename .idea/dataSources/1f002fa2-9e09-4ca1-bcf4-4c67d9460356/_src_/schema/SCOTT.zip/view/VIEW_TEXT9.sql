CREATE VIEW VIEW_TEXT9 AS select count(*),sum(sal+nvl(comm,0)),deptno from emp group by deptno
/
