CREATE VIEW VIEW_TEXT10 AS select "DEPTNO","ENAME" from (select deptno,ename from emp)
where deptno>20
/
