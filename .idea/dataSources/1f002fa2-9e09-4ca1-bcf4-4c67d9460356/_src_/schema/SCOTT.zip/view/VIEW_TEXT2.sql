CREATE VIEW VIEW_TEXT2 AS select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO" from emp where sal+nvl(comm,0)>2000
/
