CREATE VIEW VIEW_TEXT8 AS select e."EMPNO",e."ENAME",e."JOB",e."MGR",e."HIREDATE",e."SAL",e."COMM",e."DEPTNO",d.dname from emp e ,dept d
where e.deptno=d.deptno
/
