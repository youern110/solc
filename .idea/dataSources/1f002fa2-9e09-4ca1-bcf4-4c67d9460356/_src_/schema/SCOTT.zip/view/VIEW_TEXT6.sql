CREATE VIEW VIEW_TEXT6 AS select * from abc
/
