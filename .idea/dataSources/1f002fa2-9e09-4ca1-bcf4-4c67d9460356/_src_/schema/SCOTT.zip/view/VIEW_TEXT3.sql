CREATE VIEW VIEW_TEXT3 AS select e."EMPNO",e."ENAME",e."JOB",e."MGR",e."HIREDATE",e."SAL",e."COMM",e."DEPTNO",d.loc from emp e,dept d where e.deptno=d.deptno and dname='SALES'
with read only
/
