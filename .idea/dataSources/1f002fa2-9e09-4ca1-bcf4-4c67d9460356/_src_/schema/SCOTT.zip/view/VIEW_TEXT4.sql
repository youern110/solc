CREATE VIEW VIEW_TEXT4 AS select "EMPNO","ENAME","JOB","MGR","HIREDATE","SAL","COMM","DEPTNO" from emp where sal>2000
with check option
/
