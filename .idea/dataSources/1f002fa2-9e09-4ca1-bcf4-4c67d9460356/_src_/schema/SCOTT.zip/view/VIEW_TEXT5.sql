CREATE VIEW VIEW_TEXT5 AS select ename,job from emp
/
