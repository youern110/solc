CREATE procedure printemp(dno emp.deptno%type)
as
  mename emp.ename%type;
  mjob emp.job%type;
  msal emp.sal%type;
begin
  select ename,job,sal into mename,mjob,msal from emp where empno=dno;
  dbms_output.put_line('姓名：'||mename||',职位：'||mjob||',薪水：'||msal);
exception
  when no_data_found then
    dbms_output.put_line('对不起，不存在此用户');
end;
/
