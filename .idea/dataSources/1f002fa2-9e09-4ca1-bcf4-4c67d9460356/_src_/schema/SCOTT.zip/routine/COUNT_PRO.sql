CREATE procedure count_pro(dpn number,counts out number)
as
begin
  select count(*) into counts from emp where deptno=dpn;
end;
/
