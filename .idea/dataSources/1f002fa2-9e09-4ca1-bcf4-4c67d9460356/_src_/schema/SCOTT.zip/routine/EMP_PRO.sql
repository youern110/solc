CREATE procedure emp_pro(epn in number,ename out varchar2,job out varchar2,sal out number)
as
begin

  select ename,job,sal into ename,job,sal from emp where empno=epn;
  dbms_output.put_line('姓名：'||ename||',职位：'||job||',薪水：'||sal);
exception
  when no_data_found then
    dbms_output.put_line('对不起，不存在此用户！');
end;
/
