CREATE procedure sal_pro(dpn number,maxsalname out varchar2,minsalname out varchar2)
as
begin
  select ename into maxsalname from emp where sal = (select max(sal) from emp where deptno=dpn) and deptno=dpn;
  select ename into minsalname from emp where sal = (select min(sal) from emp where deptno=dpn) and deptno=dpn;
  dbms_output.put_line('最高薪水员工姓名：'||maxsalname||',最低薪水员工姓名：'||minsalname);
end;
/
