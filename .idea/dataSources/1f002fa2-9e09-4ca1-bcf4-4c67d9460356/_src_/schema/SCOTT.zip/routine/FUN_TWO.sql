CREATE function fun_two(eno number)
return varchar2
as
  mename emp.ename%type;
begin
  select ename into mename from emp where empno=eno;
  return mename;
exception
  when no_data_found then
    dbms_output.put_line('没有找到数据！');
    return '';
end;
/
