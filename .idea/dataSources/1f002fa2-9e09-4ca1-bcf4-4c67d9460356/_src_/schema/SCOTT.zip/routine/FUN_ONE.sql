CREATE function fun_one
return int
as
  v_num number;
begin
  select max(sal)-min(sal) into v_num from emp ;
  return v_num;
end;
/
